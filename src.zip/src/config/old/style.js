
export const minVH = "70vh";
export const minVW = "50vW";
export const bgBreadcrumb = "bg-primary-subtle";
export const containerJS="container-fluid";
export const mainAll = " ";
export const allstyle= {
 "minVH": minVH ,
  "minVW": minVW ,
  "bgBreadcrumb":bgBreadcrumb , 
   "containerJS": containerJS,
};

