export const navigation = [
  { name: "Home", href: "/" },
  { name: "Search", href: "/search" },
  { name: "Contact", href: "/contact" },
  { name: "About", href: "/about" },
  { name: "Support", href: "/test" },
//   { name: "Help", href: "#" },
];