import { useSelector } from "react-redux";

function Test() {
  const state = useSelector(state => state) 

  return (
    <div className=" fixed bottom-1 left-5 size-5 bg-red-400">
      {state.x}
    </div>
  );
}

export default Test;
