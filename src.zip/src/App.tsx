import React, { Suspense } from 'react';
import { RecoilRoot } from 'recoil';
import { BrowserRouter, Routes, Route, useLocation } from "react-router-dom";
import { AnimatePresence, motion } from "framer-motion";

import Header from './components/header/Header';

const Home = React.lazy(() => import("./pages/Home"));
const Test = React.lazy(() => import("./pages/Test"));
const NotFound = React.lazy(() => import("./components/notfound/notfound"));
const Footer = React.lazy(() => import("./components/footer/Footer"));


/*
const Search = React.lazy(() => import("@/pages/Search"));
const Info = React.lazy(() => import("@/pages/Info"));
const Profile = React.lazy(() => import("@/pages/Profile"));
*/
// import Test from './test/test';
import { initTheme } from "./components/Theme/Theme";
// import { ReactReduxContext } from 'react-redux';
initTheme();
function App() {
  return (
    <>
      <div className="isolate">
          <RecoilRoot>
            <BrowserRouter>                    
              <Header/>
              <AnimatedRoutes />
              <Test/>
              <Footer />
            </BrowserRouter>
          </RecoilRoot>
      </div>
    </>
  );
}

function PageWrapper({ children }: { children: React.ReactNode }) {
  return (
    <motion.main
    initial={{ opacity: 0, y: 0 }}
    animate={{ opacity: 1, y: 0 }}
    exit={{ opacity: 0, y: 0 }}
    transition={{ duration: 0.25 }}
    className=" min-h-screen pt-[60px] bg-white dark:bg-gray-950"
    >
      {children}
    </motion.main>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  // console.log(location);  
  return (
  <>
    <AnimatePresence mode="wait">
      <Suspense fallback={<div className="h-screen text-2xl grid place-items-center">Loading...</div>}>
        <Routes location={location} key={location.pathname}>
          <Route path="/" element={<PageWrapper><Home /></PageWrapper>} />
          <Route path="*" element={<NotFound />} />
          {/* 
          <Route path="/search" element={<PageWrapper><Search /></PageWrapper>} />
          <Route path="/info" element={<PageWrapper><Info /></PageWrapper>} />
          <Route path="/profile" element={<PageWrapper><Profile /></PageWrapper>} />
          */}
        </Routes>
      </Suspense>
    </AnimatePresence>
  </>
  );
}

export default App;