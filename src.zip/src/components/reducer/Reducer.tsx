

function themeReducer(resultState:any,action:Number) {
    console.log("themeReducer: ",resultState,action);
    
    return action; 
}

export default themeReducer;