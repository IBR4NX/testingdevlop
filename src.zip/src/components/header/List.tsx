import React from "react";
import { Link } from "react-router-dom";
import { navigation } from "@/config/routes";

function List() {
  return (
    <>
        <ul className=" -mx-4 ">
          {navigation.map((item,index) => (
            <li key={item.name} className="h-[48px]">
              <Link to={item.href} 
              className={`
               hover:transform-cpu hover:bg-gray-500/10 ${index!=navigation.length-1&& "border-b"}  border-gray-500/5 block w-full p-3 rounded-lg transition-all rounded-4xlxl text-base/6 px-3 font-semibold `}>
                {item.name}
              </Link>
            </li>
          ))}
        </ul>
    </>
  );
}

export default List;
