import { useEffect, useState } from "react";
import BTNTheme from "../Theme/Theme";
import logo from "../../assets/logo/logo9.png";
import { Link } from "react-router-dom";
import List from "./List";
import { PiDotsThreeOutlineVertical } from "react-icons/pi";
function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  //  const [mode, setMode] = useState(localStorage.getItem("theme") ==="dark" );
  window.addEventListener("resize", () => {
    if (!mobileMenuOpen && window.innerWidth > 1024) {
      setMobileMenuOpen(false);
    }
  })
  useEffect(()=>{
    if (mobileMenuOpen) {
      document.documentElement.classList.add("scrollbar-hidden");
      return;}
      document.documentElement.classList.remove("scrollbar-hidden"); 
  },[mobileMenuOpen])

  // const handleTestChange=(e:any)=>{
  //   console.log(e.target.value);
  // }
  
  return (
    <>
    
      <header className=" text-gray-950 dark:text-white">
        <div className=" fixed inset-x-0 top-0 z-50  border-b border-gray-950/10 dark:border-white/15 ">
          <div className="bg-white dark:bg-gray-950 pr-(--scrollbar-padding) ">
            <nav className="flex justify-between items-center - h-[60px] *:max-h-14 px-5 py-3">
              <div className=" flex h-full flex-1 min-w-1/2 ">
                <button
                  onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
                  className="  h-full w-8 p-1 cursor-pointer ring ring-gray-950/5 text-gray-950 dark:text-white "
                >
                  {/* <span className="sr-only">Menu</span> */}
                  <svg
                    className=" "
                    fill="none"
                    stroke="currentColor"
                    viewBox="0 0 24 24"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      strokeWidth={2}
                      d="M4 6h16M4 12h16M4 18h16"
                    />
                  </svg>
                </button>
                <Link to="/">
                  <span className="sr-only hidden" >Ibovs</span>
                  <img alt="" src={logo}
                    className={`  h-full self-center transition-all duration-500 ease-in-out delay-75
                    ${mobileMenuOpen && "translate-x-[150%]"} `}
                  />
                </Link>
              </div>
              <div className="flex flex-1 gap-2 h-full minw  justify-end items-center  ">
                <div className="">
                  {/* input Search */}
                  {/* <input type="text" placeholder="Search" onChange={handleTestChange} className="px-1.5 text-xs border border-gray-950/50 rounded-full w-20 h-7" /> */}
                  {/* <button type="button" className="inline-flex items-center gap-1 rounded-full bg-gray-950/2 px-2 py-1 inset-ring inset-ring-gray-950/8 dark:bg-white/5 dark:inset-ring-white/2"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 16 16" className="-ml-0.5 size-4 fill-gray-600 dark:fill-gray-500"><path fill-rule="evenodd" d="M9.965 11.026a5 5 0 1 1 1.06-1.06l2.755 2.754a.75.75 0 1 1-1.06 1.06l-2.755-2.754ZM10.5 7a3.5 3.5 0 1 1-7 0 3.5 3.5 0 0 1 7 0Z" clip-rule="evenodd"></path></svg><kbd className="hidden font-sans text-xs/4 text-gray-500 dark:text-gray-400 [.os-macos_&amp;]:block">⌘K</kbd><kbd className="hidden font-sans text-xs/4 text-gray-500 not-[.os-macos_&amp;]:block dark:text-gray-400">Ctrl&nbsp;K</kbd></button> */}
                </div>
                <div className="h-6 ">
                  <BTNTheme />
                </div>
                <span className={` cursor-pointer md:hidden `}>
                  <PiDotsThreeOutlineVertical />
                </span>
              </div>
            </nav>
          </div>
        </div>
        {/* <div className=" h-14 inset-x-0 bg-black"></div> */}
        {/* <div className=" inset-0 pt-14 bg-white fixed top-0 "></div> */}

        <div className="  dark:text-white    ">
          <div
            onClick={() => setMobileMenuOpen(false)}
            className={`fixed inset-x-0 h-screen bg-gray-950/30 ${
              !mobileMenuOpen && "hidden"
            } `}
          ></div>
        </div>
        <div
          className={`sm:max-w-xs fixed top-[60px] -translate-x-full w-full h-screen left-0 transition-transform duration-300 ease-in-out 
            ${mobileMenuOpen && "translate-x-0!"} `}
        >
          <div className="p-6 *:py-3 overflow-hidden divide-y border-l bg-white dark:bg-gray-950 border-y-gray-950/10 dark:border-white/10 h-screen">

          <div className="   ">
            <List />
          </div>
          <div className="">
            login
          </div>
          </div>
        </div>
      </header>
    </>
  );
}

export default Header;
