const navigation = [
  { name: 'Home', href: '/' },
  { name: 'Support', href: '/test' },
  { name: 'Help', href: '#' },
  { name: 'Company', href: '/' },
]

export default navigation;