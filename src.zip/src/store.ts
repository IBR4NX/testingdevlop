import { configureStore } from '@reduxjs/toolkit'

export const store = configureStore({
  reducer: {},
})
// Infer the `RootState` and `AppDispatch` types from the store itself
export type RootState = ReturnType<typeof store.getState>
// Inferred type: {posts: PostsState, comments: CommentsState, users: UsersState}
export type AppDispatch = typeof store.dispatch

import {  createStore } from '@reduxjs/toolkit'
const reducerTest=(state={x:0},active:any)=>{
  if (active.type==="plus") {
    return{x:state.x+1}
  }
  else if (active.type==="minse") {
    return {x:state.x-1}    
  }
  return state
}
export const TestStore =createStore(reducerTest)