// import { ibovs_url, ibovs_api, ibovs_app, ibovs_routes } from "../config"
//<##☆##> api <##☆##> 
export const ibovs_url = "http://localhost:8000";
export const ibovs_api = {
  base: "http://localhost:8000",
  api: "/api",
  info: "/video/info",
  download: "/video/download",
  merge: "/video/merge",
  user_info: "/user/info",
  auth_login: "/auth/login",
};

// <##☆##> APP_CONFIG<##☆##>  
export const ibovs_app = {
  SITE_NAME: "MyWebsite",
  VERSION: "1.0.0",
  DEFAULT_TITLE: "MyWebsite",
};

// <##☆##> ROUTES  <##☆##>  
export const ibovs_routes = {
  base: "http://localhost:5173"
  root: "/",
  replace: "/app/"
  app: {
    base: "/app",
    home: "/app/home",
    info: "/app/info",
    search: "/app/search",
  },

  admin: {
    base: "/admin",
    home: "/admin/home",
    user: "/admin/user",
  },
};