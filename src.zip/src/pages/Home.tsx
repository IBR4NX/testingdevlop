import { useMemo, useReducer, useState } from "react"
// import themeReducer from "../components/reducer/Reducer";
import { useDispatch, useSelector } from "react-redux";
export default function Home() {
  const [test, setTest] = useState(false);
  const m = useSelector(state => state);
  const dispatch = useDispatch();
  console.log(m.x);
  
  // console.log("handle",e.target.value);
//   const [state, dispatch] = useReducer(themeReducer , 10)
// const handleOnClick = (e:any) => {
//     dispatch("red");
//   };
  return (
    <>
    <div className=" text-6xl h-screen px-10">
    <h1 className='    ' > Home {m.x}</h1>
    <div className=" *:size-10 ">
      <button onClick={()=>dispatch({type:"plus"})} >+</button>
      <button onClick={()=>dispatch({type:"minse"})}>-</button>

      </div>
    </div>
    </>
  )
}