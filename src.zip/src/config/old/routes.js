const ROUTES = {
  base: "http://localhost:5173",
  root: "/",
  replace: "/app/",
  app: {
    base: "/app",
    home: "/app/home",
    info: "/app/info",
    search: "/app/search",
  },

  admin: {
    base: "/admin",
    home: "/admin/home",
    user: "/admin/user",
  },
};
export const ROUT_ADMIN = {
  home: {
    label: "Home",
    path: "/admin/home",
  },
  search: {
    label: "Search",
    path: "/admin/search",
  },
  test: {
    label: "Test Code",
    path: "/admin/test",
  },};
  
export const ROUT = {
  home: {
    label: "Home",
    path: "/",
  },
  search: {
    label: "Search",
    path: "/search",
  },
  test: {
    label: "Test Code",
    path: "/test",
  },
  about: {
    label: "About",
    path: "/about",
  },
  contact: {
    label: "Contact",
    path: "/contact",
  },
  contact2: {
    label: "Contact",
    path: "/contact2",
  },
  contact3: {
    label: "Contact",
    path: "/contact3",
  },
  contact4: {
    label: "Contact",
    path: "/contact4",
  },
  contact5: {
    label: "Contact",
    path: "/contact5",
  },
  contact6: {
    label: "Contact",
    path: "/contact6",
  },
  contact7: {
    label: "Contact",
    path: "/contact7",
  },
};
export default ROUTES