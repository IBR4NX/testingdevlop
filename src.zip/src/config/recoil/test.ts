import { atom } from "recoil";

export const logined = atom<boolean>({
  key: "logined", // يجب أن يكون فريد
  default: false,
});

export const userinfo = atom<{ name: string }>({
  key: "userinfo",
  default: { name: "ibo", },
});

export const baseurl = atom<string>({
  key: "baseurl",
  default: "http://localhost:5173",
});