
// <##☆##> APP_CONFIG<##☆##>  
 const APP_CONFIG = {
  SITE_NAME: "MyWebsite",
  VERSION: "1.0.0",
  DEFAULT_TITLE: "MyWebsite",
};

export default APP_CONFIG