type Theme = "light" | "dark" | "system";
import { useState } from "react";
import { MdOutlineLightMode, MdOutlineDarkMode, MdSettingsSystemDaydream} from "react-icons/md";
document.documentElement.classList.toggle(
  "dark",
  localStorage.theme === "dark" ||
  (!("theme" in localStorage) && window.matchMedia("(prefers-color-scheme: dark)").matches),
);
const getSystemTheme = () =>
  window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";

 const applyTheme = (theme: Theme) => {
  const html = document.documentElement;
  html.classList.remove("dark","light");
  if (theme === "system") {
    const systemTheme = getSystemTheme();
    html.classList.add(systemTheme);
    localStorage.setItem("theme", "system");
    return;
  }
  html.classList.add(theme);
  localStorage.setItem("theme", theme);
};

export const initTheme = () => {
  const saved = localStorage.getItem("theme") as Theme | null;
  
  if (!saved || saved === "system") {
    applyTheme("system");
  } else {
    applyTheme(saved);
  }
};
export default function BTNTheme() {
  const [dataChecked, setdataChecked] = useState(localStorage.getItem("theme") as Theme );
  
  
  //  }
  const handleChangeTheme=(theme:Theme)=>{
    applyTheme(theme);
    setdataChecked(theme);
  }
  
  return (
    <div className=" inl p-0.5 px-1 flex flex-row gap-0.5 h-full rounded-full bg-gray-950/5 text-gray-950 dark:bg-white/10 dark:text-white  ">
      <span
        onClick={() => handleChangeTheme("light") }
        className=" rounded-full *:p-0.5 max-sm:p-0.5 *:size-full data-checked:bg-white data-checked:ring data-checked:inset-ring data-checked:ring-gray-950/10 data-checked:inset-ring-white/10 dark:data-checked:bg-gray-700 dark:data-checked:text-white dark:data-checked:ring-transparent"
        role="radio" data-checked={ (dataChecked==="light")?"": undefined} >
        <MdOutlineLightMode className=" flex m-auto "/>
      </span>

      <span
        onClick={() => handleChangeTheme("dark")}
        className=" rounded-full *:p-0.5 max-sm:p-0.5 *:size-full data-checked:bg-white data-checked:ring data-checked:inset-ring data-checked:ring-gray-950/10 data-checked:inset-ring-white/10 dark:data-checked:bg-gray-700 dark:data-checked:text-white dark:data-checked:ring-transparent"
     role="radio" data-checked={ (dataChecked==="dark")?"": undefined}  >
        <MdOutlineDarkMode />
      </span>

      <span
        onClick={() => handleChangeTheme("system")}
        className=" rounded-full *:p-1 max-sm:p-0.5 *:size-full data-checked:bg-white data-checked:ring data-checked:inset-ring data-checked:ring-gray-950/10 data-checked:inset-ring-white/10 dark:data-checked:bg-gray-700 dark:data-checked:text-white dark:data-checked:ring-transparent"
      role="radio" data-checked={ (dataChecked==="system")?"": undefined} >
        <MdSettingsSystemDaydream />
      </span>
    </div>
  );
}