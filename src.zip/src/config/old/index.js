
import ROUTES ,{ROUT ,ROUT_ADMIN} from "./routes";
export * from "./routes";
import API from "./api";
import APP_CONFIG from "./app";
export * from "./setting";
export * from "./style";
export { ROUTES,ROUT,ROUT_ADMIN, API, APP_CONFIG,
APP_CONFIG as default,

 
};