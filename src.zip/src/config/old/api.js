//<##☆##> api <##☆##> 
const API_URL = "http://127.0.0.1:8000";
const API = {
  base: "http://127.0.0.1:8000",
  api: "/api",
  info: "/video/info",
  download: "/video/download",
  merge: "/video/merge",
  user_info: "/user/info",
  auth_login: "/auth/login",
};
export {API as default ,API, API_URL}