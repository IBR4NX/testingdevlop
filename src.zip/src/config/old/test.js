
export const link_home = "http://localhost:5173/app";
export const link_admin = "http://localhost:5173/app";
/*
export const cons=tant = value;
export const cons=tant = value;
*/
export const mainH = "h-25";
export const userinfo = {
 user:"Ibovs",
 name : "Ibrahim",
 fullName:"Ibrahim Al-Mekhlafi",
 engName:"eng/ Ibrahim",
 dev:"development by ibrahim Al-mekhlafi",
}
export const byUrl ={
 insta:"https://www.instagram.com/ibovs",
 face: "https://www.facebook.com/ibovs",
 
}